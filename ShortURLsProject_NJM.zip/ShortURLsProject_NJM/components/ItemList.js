import * as React from 'react';
import { Text, View, StyleSheet, Image, ScrollView } from 'react-native';

export default function ItemList(props) {
  return (
      <View style={styles.container}>
        <Text style={styles.alias}>
          {props.data.alias}
        </Text>
        <Text style={styles.short}>
          {props.data.short}
        </Text>
      </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 4,
    flexDirection: "row",
    alignItems: 'center',
    justifyContent: 'center',
    flexWrap: "nowrap",
  },
  alias: {
    fontSize: 14,
    fontWeight: 'bold',
    textAlignVertical:"center",
    width: 50
  },
  short: {
    padding: 5,
    width: 200,
    textAlignVertical: "center"
  }
});