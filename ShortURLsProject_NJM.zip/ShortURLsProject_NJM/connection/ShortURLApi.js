
const getShortURL=(url)=>{
  return new Promise((resolve,eject)=>{
    if(url!=""){
      fetch("https://url-shortener-nu.herokuapp.com/api/alias",{
       method: "POST",
       headers: {
          "Content-Type":"application/json"
        },
        body: JSON.stringify({
          url: url
        })
      })
      .then(response=>{
        if(response.status==200){
          response.json().then(body=>{
            resolve({
              alias: body.alias,
              short: body._links.short
            })
          }).catch(error=>{
            eject("Error")
          })
        }
        else{
          eject("Error")
        }
      })
      .catch(error=>{
        eject("Error")

      })
    }else{
      eject("Introduzca una URL")
    }
      
  })
}
export default getShortURL;
