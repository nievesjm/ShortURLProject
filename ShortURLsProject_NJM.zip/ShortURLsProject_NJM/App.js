import React, {useState} from "react";
import {Text, View, StyleSheet, TextInput, Button, ScrollView, TouchableOpacity} from "react-native"
import ShortURLApi from "./connection/ShortURLApi"
import ItemList from "./components/ItemList"

const App=()=>{

  const [lista, setLista]=useState([])
  const [url, setURL]=useState([])
  return (
      <View style={estilo.container}>
        <View style={estilo.header}>
          <TextInput style={estilo.input} value={url} onChangeText={url=> setURL(url)} />
          <TouchableOpacity style={estilo.bot} onPress={()=>{
            ShortURLApi(url).then(datos=>{
            setLista([...lista, datos])
            setURL([""])
             })
            }}><Text>Enviar</Text>
           </TouchableOpacity>
        </View>
        
        <View>
          <Text style={estilo.texto}>URLs Recientes</Text>
          <ScrollView>
            <View style={estilo.historial}>
              {
              lista.reverse().map(item=><ItemList data={item}/>)
              }
            </View>
         </ScrollView>
       </View>
      </View>
  )
};

const estilo = StyleSheet.create({
  container: {
    //flex: 1,
    marginTop: 70,
    alignItems: "center",
    },
  header:{
    flexDirection: "row"
  },
  input:{
    borderColor: "#2c7784", 
    borderWidth: 2, 
    borderRadius: 10,
    height: 30, 
    width: 230, 
    marginRight: 20,
    padding: 5},
  bot: {
    borderRadius: 10,
    height: 30,
    width: 60,
    backgroundColor: "#8fcfc1",
    alignItems: "center",
    padding: 5
  },
  texto:{
    fontWeight: "bold",
    marginTop: 20
  },
  historial:{
    marginTop: 2
  }
})
export default App;